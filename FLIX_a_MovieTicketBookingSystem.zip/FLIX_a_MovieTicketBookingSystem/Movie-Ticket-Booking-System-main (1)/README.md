<div align="center">
  <h1> Movie-Ticket-Booking-System </h1>
</div>

Movie Ticket Booking Syatem using HTML-CSS-JavaScript
